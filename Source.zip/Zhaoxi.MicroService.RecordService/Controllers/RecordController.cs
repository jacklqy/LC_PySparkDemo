﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Zhaoxi.MicroService.Utility;

namespace Zhaoxi.MicroService.RecordService.Controllers
{
	//dotnet run --urls=http://127.0.0.1:8092
	[ApiController]
	[Route("[controller]")]
	public class RecordController : Controller
	{
		private readonly ILogger<RecordController> _logger;

		public RecordController(ILogger<RecordController> logger)
		{
			_logger = logger;
			_logger.LogInformation("控制器被构造。。。");
		}

		[HttpGet]
		public List<string> Get(int id)
		{
			ApiHelper.InvokeApi("https://www.cnblogs.com/");
			ApiHelper.InvokeApi("http://www.baidu.com");
			#region 随机报错
			if (id > 10)
			{
				if (new Random().Next(0, 10) > 7)//20%失败率
					throw new Exception("LessonService Error");
			}
			#endregion
			List<string> lessonList = new List<string>();
			lessonList.Add("Redis专题：666分钟");
			lessonList.Add("IOC/AOP扩展定制：888分钟");
			lessonList.Add("DDD领域驱动设计：888分钟");
			lessonList.Add("分布式事务实现&原理 ：666分钟");
			return lessonList;
		}
	}
}