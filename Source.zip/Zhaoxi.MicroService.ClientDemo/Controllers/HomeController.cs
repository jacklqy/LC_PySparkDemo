﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Zhaoxi.MicroService.ClientDemo.Models;
using Zhaoxi.MicroService.ClientDemo.Utility;
using Zhaoxi.MicroService.Model;

namespace Zhaoxi.MicroService.ClientDemo.Controllers
{

	//dotnet run --urls=http://127.0.0.1:8090
	//http://127.0.0.1:8090/home?id=135
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;

		public HomeController(ILogger<HomeController> logger)
		{
			_logger = logger;
			_logger.LogInformation("控制器被构造。。。");
		}

		public IActionResult Index()
		{
			try
			{
				int id = new Random().Next(5, 13);
				string userurl = $"http://127.0.0.1:8091/user?id={id}";
				string content = ApiHelper.InvokeApi(userurl);
				var userInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<User>(content);
				base.ViewBag.UserName = userInfo.Name;
				string lessonurl = $"http://127.0.0.1:8092/Lesson?id={userInfo?.Id}";
				string lesson = ApiHelper.InvokeApi(lessonurl);
				base.ViewBag.Lessons = Newtonsoft.Json.JsonConvert.DeserializeObject<List<string>>(lesson);
				string recordurl = $"http://127.0.0.1:8093/Record?id={userInfo?.Id}";
				string record = ApiHelper.InvokeApi(recordurl);
				base.ViewBag.Records = Newtonsoft.Json.JsonConvert.DeserializeObject<List<string>>(record);

			}
			catch (Exception ex)
			{
				_logger.LogError(Newtonsoft.Json.JsonConvert.SerializeObject(ex));
				throw ex;

			}

			return View();
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}
