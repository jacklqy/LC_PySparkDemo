﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zhaoxi.ElasticSearchCore
{
	public class Deviceinfo
	{

		public int Type { get; set; }
		public int Status { get; set; }
		public DateTime ActionTime { get; set; }
	}
}
