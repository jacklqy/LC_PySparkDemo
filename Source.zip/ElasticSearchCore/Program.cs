﻿using Elasticsearch.Net;
using ElasticSearchCore;
using Nest;
using System;
using System.Collections.Generic;
using System.Data;
namespace Zhaoxi.ElasticSearchCore
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				//Install-Package NEST 

				{

					// Test.Show();
					//Console.ReadKey();

					#region Deviceinfo
					//var settings = new ConnectionSettings(new Uri("http://192.168.3.204:9200"))
					//.DefaultIndex("device2");
					//var client = new ElasticClient(settings);

					//var response0 = new SearchResponse<object>();

					//var ss = client.SearchTemplate<Deviceinfo>(m => m.AllIndices());


					//List<Deviceinfo> dirverinfos = new List<Deviceinfo>();
					//for (int i = 0; i < 50; i++)
					//{
					//	dirverinfos.Add(new Deviceinfo()
					//	{
					//		Type = 1,
					//		Status = 1,
					//		ActionTime = DateTime.UtcNow
					//	}); ;

					//}
					//for (int i = 0; i < 50; i++)
					//{
					//	dirverinfos.Add(new Deviceinfo()
					//	{
					//		Type = 1,
					//		Status = 1,
					//		ActionTime = DateTime.UtcNow
					//	}); ;

					//}
					//for (int i = 0; i < 50; i++)
					//{
					//	dirverinfos.Add(new Deviceinfo()
					//	{
					//		Type = 2,
					//		Status = 1,
					//		ActionTime = DateTime.UtcNow
					//	}); ;

					//}
					//client.IndexMany<Deviceinfo>(dirverinfos); 

					//var dt = SendByWebRequest.GetDataBySql("select * from device2");
					//Console.WriteLine(dt.Rows.Count);
					#endregion



					#region clayindex --text  
					// 创建的map在准备数据里面

					//var list1 = SendByWebRequest.GetDataBySql("select * from clayindex where  address like '%蜀%' ");
					//Console.WriteLine(list1.Rows.Count);
					var clayindex = SendByWebRequest.Post("select * from clayindex where address like '%蜀%'");
					Console.WriteLine(clayindex);

					//到这边，基本操作，sql，sdl== 推荐大家是sql ===
					#endregion

					TestData testData = new TestData();
					//testData.IndexMany();
					//Console.WriteLine("ok");
					testData.Search();
					//Console.WriteLine("ok");
				}

			}
			catch (Exception ex)
			{

				Console.WriteLine(ex.Message);
			}


		}
	}
}
