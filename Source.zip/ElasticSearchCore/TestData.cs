﻿using Nest;
using System;
using System.Collections.Generic;
using System.Text;

namespace Zhaoxi.ElasticSearchCore
{
	public class TestData
	{
		#region 集群连接方式
		//var uris = new[]
		//        {
		//   	new Uri("http://localhost:9200"),
		//  new Uri("http://localhost:9201"),
		//  new Uri("http://localhost:9202"),
		//        };
		//var connectionPool = new SniffingConnectionPool(uris);
		//var settings = new ConnectionSettings(connectionPool)
		//	.DefaultIndex("people"); 
		//var client = new ElasticClient(settings);
		#endregion
		public void Trace(string message)
		{

			var settings = new ConnectionSettings(new Uri(Url.url))
		.DefaultIndex("traceinfolog");
			var client = new ElasticClient(settings);
			TraceInfo traceInfo = new TraceInfo()
			{
				RpcID = Guid.NewGuid().ToString(),
				Message = message,
				Time = DateTime.Now
			};
			client.IndexDocument(traceInfo);

			//client.Index(traceInfo, i => i.Index("traceinfolog"));

			//client.Index(new IndexRequest<TraceInfo>(traceInfo, "TraceInfoLog"));
		}

		public void IndexMany()
		{
			var settings = new ConnectionSettings(new Uri(Url.url))
			.DefaultIndex("order");
			var client = new ElasticClient(settings);
			// 这些代码是低代码编程视频里面用到各种报表的原数据
			List<OrderInfo> orderInfos = new List<OrderInfo>();
			for (int i = 0; i < 20; i++)
			{
				orderInfos.Add(new OrderInfo()
				{

					Orderid = Guid.NewGuid().ToString(),
					ActionTime = DateTime.UtcNow.AddMinutes(-15),
					Name = "clay" + i,
					Address = "南京",
					Status = "购物车"
				});
			}
			for (int i = 0; i < 20; i++)
			{
				orderInfos.Add(new OrderInfo()
				{

					Orderid = Guid.NewGuid().ToString(),
					ActionTime = DateTime.UtcNow.AddMinutes(-20),
					Name = "clay" + i,
					Address = "南京2",
					Status = "支付"
				});
			}

			for (int i = 0; i < 20; i++)
			{
				orderInfos.Add(new OrderInfo()
				{

					Orderid = Guid.NewGuid().ToString(),
					ActionTime = DateTime.UtcNow.AddMinutes(-2),
					Name = "clay" + i,
					Address = "南京2",
					Status = "未支付"
				});
			}
			for (int i = 0; i < 20; i++)
			{
				orderInfos.Add(new OrderInfo()
				{

					Orderid = Guid.NewGuid().ToString(),
					ActionTime = DateTime.UtcNow.AddMinutes(-9),
					Name = "clay" + i,
					Address = "南京2",
					Status = "已配送"
				});
			}
			client.IndexMany<OrderInfo>(orderInfos);
			//List<Person> peoples = new List<Person>();
			//for (int i = 0; i < 10; i++)
			//{
			//	Person personinfo = new Person
			//	{
			//		Id = i,
			//		FirstName = "Martijn" + i,
			//		LastName = "Laarman" + i
			//	};
			//	peoples.Add(personinfo);
			//}
			//client.IndexMany<Person>(peoples);
		}

		public void Search()
		{

			var settings = new ConnectionSettings(new Uri(Url.url))
			   .DefaultIndex("people");
			var client = new ElasticClient(settings);

			//List<Person> list = new();
			//for (int i = 0; i < 10; i++)
			//{
			//	Person person = new Person();
			//	person.Id = i;
			//	person.FirstName = "张三";
			//	list.Add(person);
			//}
			//client.IndexMany<Person>(list);
			// 数据刷盘延迟--默认1s 
			var searchResponse = client.Search<Person>(s => s
				.From(0)
	.Size(10)
		.Query(q => q
					 .Match(m => m
						.Field(f => f.FirstName)
						.Query("张三")
					 )
				)
			);
			var people = searchResponse.Documents;
			Console.WriteLine("查询结果");
			foreach (var item in people)
			{
				Console.WriteLine($"id:{item.Id},firstname:{item.FirstName},lastname:{item.LastName}");
			}


			Console.WriteLine("**********");
			// select * from tabel where name="1" and age>1

			//{ "query" : { "bool" : { "must": [{ "match_all" : { } }]} },"from" : 0,"size" : 1}
			//{"query" : {"bool" : {"must" : [{"match" : {"name" : {"query" : "1", "type" : "phrase"}}},{"range" : {"age" : {"gt" : "1"}}}]}},"from" : 0,"size" : 1}

			var ss = client.Search<Person>(s => s.Query(
				  m => m.Bool(
					  m => m.Must(
						  x => x.Match(m => m.Field(f => f.FirstName).Query("1")
									   ), mm => mm.Range(xx => xx.Field(f => f.Id).GreaterThan(1))
								 )
						   )

				  )
			).Documents;


			//var searchResponse = client.Search<Person>(s => s
			//	.From(0)
			//	.Size(10)
			//	.Query(q => q
			//		 .Match(m => m
			//			.Field(f => f.FirstName)
			//			.Query("Martijn1")
			//		 )
			//	)
			//);
			//var people = searchResponse.Documents;
			//Console.WriteLine("查询结果");
			//foreach (var item in people)
			//{
			//	Console.WriteLine($"id:{item.Id},firstname:{item.FirstName},lastname:{item.LastName}");
			//}
		}
	}
}
