﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zhaoxi.ElasticSearchCore
{
	public class Url
	{
		public static string url = "http://192.168.1.211:9200/";
	}
}
