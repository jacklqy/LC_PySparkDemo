﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Zhaoxi.MicroService.LessonService.Controllers
{

	//dotnet run --urls=http://127.0.0.1:8092
	//http://127.0.0.1:8092/Lesson?id=1
	[ApiController]
	[Route("[controller]")]
	public class LessonController : Controller
	{
		private readonly ILogger<LessonController> _logger;

		public LessonController(ILogger<LessonController> logger)
		{
			_logger = logger;
			_logger.LogInformation("控制器被构造。。。");
		}

		[HttpGet]
		public List<string> Get(int id)
		{
			#region 随机报错
			if (id > 10)
			{
				if (new Random().Next(0, 10) > 7)//20%失败率
					throw new Exception("LessonService Error");
			}
			#endregion
			List<string> lessonList = new List<string>();
			lessonList.Add("Redis&实战&原理&调优&集群");
			lessonList.Add("IOC/AOP扩展定制");
			lessonList.Add("kafka&实战&原理&调优&集群");
			lessonList.Add("DDD领域驱动设计");
			lessonList.Add("分布式事务实现&原理");
			lessonList.Add("性能调优");
			lessonList.Add("Docker+net core云部署");
			return lessonList;
		}
	}
}