﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Zhaoxi.MicroService.Model;
using Zhaoxi.MicroService.Utility;

namespace Zhaoxi.MicroService.Service.Controllers
{
	//dotnet run --urls=http://127.0.0.1:8091
	//http://127.0.0.1:8091/user?id=1
	[ApiController]
	[Route("[controller]")]
	public class UserController : Controller
	{
		private readonly ILogger<UserController> _logger;

		public UserController(ILogger<UserController> logger)
		{
			_logger = logger;
			_logger.LogInformation("控制器被构造。。。");
		}

		[HttpGet]
		//[Route("api/User/Get")]  
		public User Get(int id = 0)
		{
			#region 随机报错
			if (id > 10)
			{
				if (new Random().Next(0, 10) > 7)//20%失败率
					throw new Exception("UserService Error");
			}
			#endregion

			List<User> users = new List<User>();
			for (int i = 0; i < 10; i++)
			{
				users.Add(
					new User()
					{
						Id = i,
						Name = "架构班学员"
					}
					);
			}
			ApiHelper.InvokeApi("https://www.cnblogs.com/");
			ApiHelper.InvokeApi("http://www.baidu.com");
		 
			return users.Where(m => m.Id == id).FirstOrDefault();
		}
	}
}